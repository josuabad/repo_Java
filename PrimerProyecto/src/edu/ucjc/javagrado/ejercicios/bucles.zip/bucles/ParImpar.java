package edu.ucjc.javagrado.ejercicios.bucles;

public class ParImpar {

	public static void main(String[] args) {
		
		for ( int par=2,impar=99 ;  par<=100  ; par+=2,impar-=2) {
			System.out.print(par+"\t"+impar+"\n");
		}

	}

}
